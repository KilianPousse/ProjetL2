var searchData=
[
  ['errorlog_0',['ErrorLog',['../logs_8c.html#a1cbaea046077d435e2c2af95f5f4b3b8',1,'ErrorLog(char *message):&#160;logs.c'],['../header_8h.html#a1cbaea046077d435e2c2af95f5f4b3b8',1,'ErrorLog(char *message):&#160;logs.c']]]
];
