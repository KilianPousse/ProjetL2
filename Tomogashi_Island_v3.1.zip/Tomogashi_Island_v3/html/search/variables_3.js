var searchData=
[
  ['frame_0',['frame',['../structplayer__t.html#aac7a833aedf133de443489bb8850b9a3',1,'player_t']]]
];
