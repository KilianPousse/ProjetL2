var searchData=
[
  ['actions_0',['actions',['../structplayer__t.html#a5e6b9ecc5c4ab8a9c6fe25764d81d597',1,'player_t']]]
];
