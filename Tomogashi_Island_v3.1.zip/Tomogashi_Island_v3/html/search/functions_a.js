var searchData=
[
  ['warninglog_0',['WarningLog',['../logs_8c.html#a2b878c29420719f1216318f6ee25b323',1,'WarningLog(char *message):&#160;logs.c'],['../header_8h.html#a2b878c29420719f1216318f6ee25b323',1,'WarningLog(char *message):&#160;logs.c']]]
];
