var searchData=
[
  ['sprites_0',['sprites',['../structplayer__t.html#aed4e3b0976e77e56cbcf4316608ab467',1,'player_t']]]
];
