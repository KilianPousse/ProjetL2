var searchData=
[
  ['logs_2ec_0',['logs.c',['../logs_8c.html',1,'']]]
];
