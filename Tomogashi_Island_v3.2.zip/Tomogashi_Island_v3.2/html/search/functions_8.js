var searchData=
[
  ['outmap_0',['outMap',['../map_8c.html#a1a9266e5ccf5dadd51b799855091a22a',1,'outMap(map_t m):&#160;map.c'],['../header_8h.html#a1a9266e5ccf5dadd51b799855091a22a',1,'outMap(map_t m):&#160;map.c']]],
  ['outwindow_1',['outWindow',['../map_8c.html#ac83f3fc4e97c234adce291ca195a0e35',1,'outWindow(int x, int y):&#160;map.c'],['../header_8h.html#ac83f3fc4e97c234adce291ca195a0e35',1,'outWindow(int x, int y):&#160;map.c']]]
];
