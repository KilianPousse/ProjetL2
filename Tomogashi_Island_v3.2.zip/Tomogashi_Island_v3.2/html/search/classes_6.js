var searchData=
[
  ['skin_5fs_0',['skin_s',['../structskin__s.html',1,'']]]
];
