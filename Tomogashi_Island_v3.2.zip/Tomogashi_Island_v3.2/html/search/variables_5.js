var searchData=
[
  ['hour_5ffont_0',['hour_Font',['../header_8h.html#adb290a60ca96c217f71023fa5c095c5b',1,'header.h']]]
];
