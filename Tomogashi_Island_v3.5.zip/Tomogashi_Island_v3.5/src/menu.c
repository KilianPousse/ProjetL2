#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "header.h"
#include "style.h"
#include "struct.h"
#include "menu.h"

/*Définiton variable globale*/

#define SCREEN_HEIGHT 480
#define SCREEN_WIDGHT 640
#define TAILLE 4
SDL_Event evenement;

void menu_destruction(bouton_t * bouton, SDL_Texture * texture){
        /*Destruction fenetre*/
    for(int j = 0; j < TAILLE ; j++){
        SDL_DestroyTexture(bouton[j].image);
        SDL_DestroyTexture(bouton[j].clique);
    }
    SDL_DestroyTexture(texture);
}

/*Structure stockée dans struct.h*/




/*En SDL obligé de mettre une fonction à argument variable*/
int menu_main(int argc, char * argv[]){

    SDL_Texture * fond = chargerTexture(IMG_FOND, renderer);
    if(fond == NULL){
        printf("PAS FOND\n");
    }
    SDL_Rect rectangle= {0,0,100,100};

    /*Définition des boutons*/


    bouton_t menu[TAILLE];
    menu[0].texte = "jouer";
    menu[1].texte = "nouvelle partie";
    menu[2].texte = "parametre";
    menu[3].texte = "quitter";

    /*Chargement des images*/
    menu[0].image = chargerTexture(IMG_BOUTON_PLAY,renderer);
    menu[0].clique = chargerTexture(IMG_BOUTON_PLAY_CLIQUE,renderer);
    menu[1].image = chargerTexture(IMG_BOUTON_NEW,renderer);
    menu[1].clique = chargerTexture(IMG_BOUTON_NEW_CLIQUE,renderer);
    menu[2].image = chargerTexture(IMG_BOUTON_SET,renderer);
    menu[2].clique = chargerTexture(IMG_BOUTON_SET_CLIQUE,renderer);
    menu[3].image = chargerTexture(IMG_BOUTON_QUIT,renderer);
    menu[3].clique = chargerTexture(IMG_BOUTON_QUIT_CLIQUE,renderer);

    /*Calcul des postitions et des rectangles => pour savoir ou l'utilisateur clique*/
    int mrec = 100;
    int espace = 10;
    int totalheight = (mrec + espace)*TAILLE; 
    int y = (SCREEN_HEIGHT - totalheight) / 2 + 300; /*On ajouter pour centrer sur l'ecran*/
    int i;
    for(i = 0; i < TAILLE; i++){
        menu[i].rectangle.x = (SCREEN_WIDGHT + espace);
        menu[i].rectangle.y = y + (mrec + espace) * i; 
        menu[i].rectangle.w = 200;
        menu[i].rectangle.h = mrec;
    }
    int quitter = 0;
    int mousex,mousey;

    while(!quitter){
        
        while(SDL_PollEvent(&evenement) != 0){
            if(evenement.type == SDL_QUIT){
                quitter = 1;
                GameExit(1);
            }
            else if(evenement.type == SDL_MOUSEBUTTONUP){
                SDL_SetCursor( cursor );
            }
            else if(evenement.type == SDL_MOUSEBUTTONDOWN){
                SDL_SetCursor( cursor_click );
                SDL_GetMouseState(&mousex,&mousey);
            }
            
             /*On récupère les coordonnées de la souris*/
            int i;
            for(i = 0; i < 4; i++){
                if(SDL_PointInRect(&(SDL_Point){mousex,mousey},&menu[i].rectangle)){
                    printf("Cliquer sur %s\n",menu[i].texte);
                    quitter = 1;
                    menu_destruction(menu, fond);
                    return i;
                    break;
                }
            }
        
        }
    
        //SDL_RenderClear(renderer);

        SDL_RenderCopy(renderer, fond, NULL, NULL);

        /*renderer des items*/
        for(i = 0;i<4;i++){
            SDL_RenderCopy(renderer, menu[i].image, NULL, &(menu[i].rectangle)); /*Rectangle*/
                /*Si on clique alors*/
                if(SDL_PointInRect(&(SDL_Point){mousex,mousey},&menu[i].rectangle)){

                    SDL_RenderCopy(renderer, menu[i].clique, NULL, &(menu[i].rectangle)); /*Rectangle*/
                    
                    
                }

        
        }
        SDL_RenderPresent(renderer);
    }

    /*musique*/
    /*Gestion musique SDL MIXER*/
    menu_destruction(menu, fond);
    return 0;
}