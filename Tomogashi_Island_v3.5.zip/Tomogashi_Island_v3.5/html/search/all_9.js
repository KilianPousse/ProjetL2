var searchData=
[
  ['limit_5ffps_0',['limit_fps',['../main_8c.html#ac2f8a53b6509da854f35d8cdaa18d3a6',1,'limit_fps(unsigned int limit):&#160;main.c'],['../header_8h.html#ac2f8a53b6509da854f35d8cdaa18d3a6',1,'limit_fps(unsigned int limit):&#160;main.c']]],
  ['limit_5fper_5fline_1',['LIMIT_PER_LINE',['../header_8h.html#a210524a73e29beec0bbfb0ce037f2e34',1,'header.h']]],
  ['logs_2ec_2',['logs.c',['../logs_8c.html',1,'']]]
];
