
typedef struct bouton_s{
    char * texte; /**< Définiton des nom des boutons*/
    SDL_Rect rectangle;  /**< Définiton du rectangle pour savoir si le joueur clique dedans ou pas*/
    SDL_Texture * image; /**< Image du bouton si pas de clique*/
    SDL_Texture * clique; /**< Image du bouton si le joueur clique dessus*/
}bouton_t;

void menu_destruction(bouton_t * bouton, SDL_Texture * texture);
int menu_main();