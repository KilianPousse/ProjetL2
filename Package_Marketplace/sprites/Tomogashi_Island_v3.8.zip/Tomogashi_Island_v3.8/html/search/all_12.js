var searchData=
[
  ['warninglog_0',['WarningLog',['../logs_8c.html#a2b878c29420719f1216318f6ee25b323',1,'WarningLog(char *message):&#160;logs.c'],['../header_8h.html#a2b878c29420719f1216318f6ee25b323',1,'WarningLog(char *message):&#160;logs.c']]],
  ['window_1',['window',['../header_8h.html#aaa8e409e04dcf575ef63fd5fb3db06f9',1,'header.h']]],
  ['window_5fname_2',['WINDOW_NAME',['../header_8h.html#a2d6acae8f9b752a5d85795baf1005907',1,'header.h']]]
];
