var searchData=
[
  ['tile_5faction_0',['tile_action',['../header_8h.html#a9c82afb7a8f8310900500133010edb37',1,'header.h']]],
  ['tileaction_1',['tileAction',['../main_8c.html#af32cba74c2d07be494e7183bf3d3ee97',1,'tileAction():&#160;main.c'],['../header_8h.html#af32cba74c2d07be494e7183bf3d3ee97',1,'tileAction():&#160;main.c']]],
  ['tilevalue_2',['tileValue',['../map_8c.html#a3735bd7f3781679e156403436a12712d',1,'tileValue(int i_map, int x, int y):&#160;map.c'],['../header_8h.html#a3735bd7f3781679e156403436a12712d',1,'tileValue(int i_map, int x, int y):&#160;map.c']]],
  ['tps_5fgame_3',['tps_game',['../header_8h.html#acddea2e6e4a413a85c9d546d69132dd1',1,'header.h']]]
];
