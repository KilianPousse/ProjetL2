var searchData=
[
  ['nord_0',['nord',['../header_8h.html#a32db8bfae4e3fc9908e95d227f464ad0aa7d434167708d0dfa76b5d8fd2ab7b4b',1,'header.h']]]
];
