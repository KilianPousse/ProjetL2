#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "header.h"
#include "struct.h"
#include "style.h"
#include "hotbar.h"

#include "inventary.h"


item_t inventary_mainhand(  ){
    return inventary.hotbar[inventary.i_hotbar];
}

int inventary_use(  ){

    if( inventary.hotbar[inventary.i_hotbar].nb <= 0 )
        return 1;

    if( inventary.hotbar[inventary.i_hotbar].nb == 1 ){
        inventary.hotbar[inventary.i_hotbar].id = 0;
    }

    (inventary.hotbar[inventary.i_hotbar].nb)--;
    return 0;
}

int inventary_contains_hotbar( unsigned int id, int limit ){

    int j = 0;

    for(int i=0; i<NUM_ITEMS; i++){
        if( inventary.hotbar[ i ].id == id ){
            j+=inventary.hotbar[ i ].nb;
            if( j == limit )
                return i;
        }
    }

    return j;
}

int inventary_contains_pcpl( unsigned int id, int limit ){

    int j = 0;

    for(int i=0; i<NB_INVENTARY_ITEM; i++){
        if( inventary.pcpl[ i ].id == id ){
            j+=inventary.pcpl[ i ].nb;
            if( j == limit )
                return i;
        }
    }

    return j;
}

int inventary_contains( unsigned int id, int limit ){

    int x = inventary_contains_pcpl(id, limit);
    return x + inventary_contains_hotbar(id, limit-x);
}


void inventary_affiche(  ){


    for(int i=0; i<NB_INVENTARY_ITEM; i++){
        if(i%NUM_ITEMS == 0)
            printf("\n");
        printf(" [id:%02d|nb:%02d]", inventary.pcpl[i].id, inventary.pcpl[i].nb );
    }
    printf("\n");


    printf("-------------------------------------------------------------------------------------\n");

    for(int i=0; i<NB_HOTBAR_ITEM; i++){
        printf(" [id:%02d|nb:%02d]", inventary.hotbar[i].id, inventary.hotbar[i].nb );
    }
    printf("\n");


}


int inventary_clear(){

    for(int i=0; i<NB_HOTBAR_ITEM; i++){
        inventary.hotbar[i].nb = 0;
        inventary.hotbar[i].id = 0;
    }

    for(int i=0; i<NB_INVENTARY_ITEM; i++){
        inventary.pcpl[i].nb = 0;
        inventary.pcpl[i].id = 0;
    }

    return 0;
}

int inventary_canGive( item_t item ){

    int nb = item.nb;

    for( int i=0; i<NB_HOTBAR_ITEM; i++ ){
        //printf("/hotbar:[id:%d|nb:%d]  -- item[id:%d|nb:%d]/\n", inventary.hotbar[i].id, inventary.hotbar[i].nb, item.id, item.nb);
        if( inventary.hotbar[i].nb <= 0 && inventary.hotbar[i].id == 0)
            return 1;
        
        if( inventary.hotbar[i].id == item.id  ){
            nb = (inventary.hotbar[i].nb + nb) - MAX_ITEM_STACK;

            if( nb <= 0 )
                return 2;
        }


    }

    for( int i=0; i<NB_INVENTARY_ITEM; i++ ){
        //printf("/iventary:[id:%d|nb:%d]  -- item[id:%d|nb:%d]/\n", inventary.pcpl[i].id, inventary.pcpl[i].nb, item.id, item.nb);
        if( inventary.pcpl[i].nb <= 0 && inventary.pcpl[i].id == 0 )
            return 1;
        
        if( inventary.pcpl[i].id == item.id  ){
            nb = (inventary.pcpl[i].nb + nb) - MAX_ITEM_STACK;

            if( nb <= 0 )
                return 2;
        }


    }


    return 0;
}

int inventary_give( item_t * item ){

    if( item->nb > MAX_ITEM_STACK )
        item->nb = MAX_ITEM_STACK;

    int i_hotbar = -1;
    int i_pcpl = -1;

    for(int i=0; i<NB_HOTBAR_ITEM; i++){

        if( i_hotbar < 0 && inventary.hotbar[i].nb <= 0 && inventary.hotbar[i].id == 0 )
            i_hotbar = i;

        if( inventary.hotbar[i].id == item->id  ){
            inventary.hotbar[i].nb += item->nb;
            item->nb = inventary.hotbar[i].nb - MAX_ITEM_STACK;
            if( inventary.hotbar[i].nb > MAX_ITEM_STACK )
                inventary.hotbar[i].nb = MAX_ITEM_STACK;

            if( item->nb <= 0 )
                return 0;
        }

    }

    for(int i=0; i<NB_INVENTARY_ITEM; i++){

        if( i_hotbar < 0 && i_pcpl < 0 && inventary.pcpl[i].nb <= 0 && inventary.pcpl[i].id == 0 )
            i_pcpl = i;

        if( inventary.pcpl[i].id == item->id  ){
            inventary.pcpl[i].nb += item->nb;
            item->nb = inventary.pcpl[i].nb - MAX_ITEM_STACK;
            if( inventary.pcpl[i].nb > MAX_ITEM_STACK )
                inventary.pcpl[i].nb = MAX_ITEM_STACK;

            if( item->nb <= 0 )
                return 0;
        }

    }

    if( item->nb > 0 ){

        if( i_hotbar >= 0 ){
            inventary.hotbar[i_hotbar] = *item;
            return 0;
        }

        if( i_pcpl >= 0 ){
            inventary.pcpl[i_pcpl] = *item;
            return 0;
        }

    }

    return 1;
}

int inventary_give_hotbar( item_t * item ){

    if( item->nb > MAX_ITEM_STACK )
        item->nb = MAX_ITEM_STACK;

    int i_hotbar = -1;

    for(int i=0; i<NB_HOTBAR_ITEM; i++){

        if( i_hotbar < 0 && inventary.hotbar[i].nb <= 0 && inventary.hotbar[i].id == 0 )
            i_hotbar = i;

        if( inventary.hotbar[i].id == item->id  ){
            inventary.hotbar[i].nb += item->nb;
            item->nb = inventary.hotbar[i].nb - MAX_ITEM_STACK;
            if( inventary.hotbar[i].nb > MAX_ITEM_STACK )
                inventary.hotbar[i].nb = MAX_ITEM_STACK;

            if( item->nb <= 0 ){
                item->nb = 0;
                item->id = 0;
                return 0;
            }
        }



    }
    
    if( item->nb > 0 ){

        if( i_hotbar >= 0 ){
            inventary.hotbar[i_hotbar] = *item;
            item->nb = 0;
            item->id = 0;
            return 0;
        }
    }


}



int inventary_give_pcpl( item_t * item ){

    if( item->nb > MAX_ITEM_STACK )
        item->nb = MAX_ITEM_STACK;

    int i_pcpl = -1;

    for(int i=0; i<NB_INVENTARY_ITEM; i++){

        if( i_pcpl < 0 && inventary.pcpl[i].nb <= 0 && inventary.pcpl[i].id == 0 )
            i_pcpl = i;

        if( inventary.pcpl[i].id == item->id  ){
            inventary.pcpl[i].nb += item->nb;
            item->nb = inventary.pcpl[i].nb - MAX_ITEM_STACK;
            if( inventary.pcpl[i].nb > MAX_ITEM_STACK )
                inventary.pcpl[i].nb = MAX_ITEM_STACK;

            if( item->nb <= 0 ){
                item->nb = 0;
                item->id = 0;
                return 0;
            }
        }

    }
    
    if( item->nb > 0 ){

        if( i_pcpl >= 0 ){
            inventary.pcpl[i_pcpl] = *item;
            item->nb = 0;
            item->id = 0;
            return 0;
        }
    }


}

int inventary_canRemove( item_t item ){

    int inv;

    if( item.nb > MAX_ITEM_STACK )
        item.nb = MAX_ITEM_STACK;

   
    for(int i=0; i<NB_HOTBAR_ITEM; i++){

        if( inventary.hotbar[i].id == item.id  ){
            inv = inventary.hotbar[i].nb;
            inv -= item.nb;

            if( inv < 0 ){
                item.nb = -(inv);
            }
            else{
                return 1;
            }
        }

    }

    for(int i=0; i<NB_INVENTARY_ITEM; i++){

        if( inventary.pcpl[i].id == item.id  ){
            inv = inventary.pcpl[i].nb;
            inv -= item.nb;

            if( inv < 0 ){
                item.nb = -(inv);
            }
            else{
                return 1;
            }
        }

    }

    return 0;
}

int inventary_remove( item_t * item ){

    if( item->nb > MAX_ITEM_STACK )
        item->nb = MAX_ITEM_STACK;

    for(int i=0; i<NB_HOTBAR_ITEM; i++){

        if( inventary.hotbar[i].id == item->id  ){
            inventary.hotbar[i].nb -= item->nb;

            if( inventary.hotbar[i].nb < 0 ){
                item->nb = -(inventary.hotbar[i].nb);
                inventary.hotbar[i].nb = 0;
                inventary.hotbar[i].id = 0;
            }
            else{
                if( inventary.hotbar[i].nb == 0 )
                    inventary.hotbar[i].id = 0;
                item->nb = 0;
                return 0;
            }
        }

    }

    for(int i=0; i<NB_INVENTARY_ITEM; i++){

        if( inventary.pcpl[i].id == item->id  ){
            inventary.pcpl[i].nb -= item->nb;

            if( inventary.pcpl[i].nb < 0 ){
                item->nb = -(inventary.pcpl[i].nb);
                inventary.pcpl[i].nb = 0;
                inventary.pcpl[i].id = 0;
            }
            else{
                if( inventary.pcpl[i].nb == 0 )
                    inventary.pcpl[i].id = 0;
                item->nb = 0;
                return 0;
            }
        }

    }

    return 1;
}

int inventary_clic( int x, int y, int * i, int * j ){

    SDL_Point point = { x, y };
    SDL_Rect rect = { 382, 190, 130, 130 };

    for(*j=0; *j<NB_INVENTARY_ITEM/NB_HOTBAR_ITEM; (*j)++){

        rect.x = 382;
        for(*i=0; *i<NB_HOTBAR_ITEM; (*i)++){

            if( SDL_PointInRect( &point, &rect ) )
                return 1;

            rect.x += 140;
            

        }
        rect.y += 140;

    }
    
    *j = -1;
    rect.x = 382;
    rect.y = 680;

    for(*i=0; *i<NB_HOTBAR_ITEM; (*i)++){

        if( SDL_PointInRect( &point, &rect ) )
                return 2;
        
        rect.x += 140;
    }




    return 0;    
}



int inventary_display(){

    int xMouse, yMouse;
    int i, j;

    SDL_bool launched_program = SDL_TRUE;
    while( launched_program ){

        SDL_Event event;

        while(SDL_PollEvent(&event)) {  

				switch(event.type) { 

					// Si croix en haut a droite selectionnée
					case SDL_QUIT:
						launched_program = SDL_FALSE;
                        GameExit(EXIT_SUCCESS);
						break; 

                    case SDL_KEYDOWN:

                        switch(event.key.keysym.sym){

                            case SDLK_i:
                            case SDLK_ESCAPE:
                                launched_program = SDL_FALSE;
                                break;
                                
					        default:		
					            break;
                        }
                        break;
                    
                case SDL_MOUSEBUTTONUP:
                    SDL_SetCursor(cursor);
                    break;
                    
                case SDL_MOUSEBUTTONDOWN:
                    SDL_SetCursor(cursor_click);
                    if( event.button.button == SDL_BUTTON_RIGHT ){
                        printf("%d/%d\n", event.button.x, event.button.y);
                        switch(inventary_clic(event.button.x, event.button.y, &i, &j) ){

                            /* Inventary */
                            case 1:
                                inventary_give_hotbar( &(inventary.pcpl[j*NB_HOTBAR_ITEM + i]) );
                                break;

                            /* Hotbar */
                            case 2:
                                inventary_give_pcpl( &(inventary.hotbar[ i]) );
                                break;

                            default:
                                break;

                        }
                    }
                    break;
                    
                    default:
                        break;
                
                }
        }

        /* Affichage */
        SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0x00, 0xFF);
        SDL_RenderClear(renderer);// Rectangle plein
                
        diplayBackground();
        displayFarm( map.y*SIZE_MAP_X + map.x );
        displayPlayer( tile_action );
        displayPNJ();
        displayOverlay();

        // Filtre noire
        SDL_SetRenderDrawColor(renderer, 0x01, 0x01, 0x00, 0x60);
        SDL_RenderFillRect(renderer, NULL);

        displayGUI();
                
        displayTime();


        
        GUI_inventary();



        SDL_RenderPresent(renderer);





    }




    return 0;
}