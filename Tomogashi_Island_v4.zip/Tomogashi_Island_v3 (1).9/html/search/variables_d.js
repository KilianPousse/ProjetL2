var searchData=
[
  ['vit_0',['vit',['../structplayer__t.html#a14e5a4b4504a4e3326da6ae2940901c2',1,'player_t']]]
];
