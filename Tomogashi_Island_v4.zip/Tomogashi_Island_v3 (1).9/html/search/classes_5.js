var searchData=
[
  ['player_5ft_0',['player_t',['../structplayer__t.html',1,'']]],
  ['prota_5fs_1',['prota_s',['../structprota__s.html',1,'']]]
];
