int main_fishing();
long fishing_waitTime();
item_t fishing_fishtype();