var searchData=
[
  ['player_0',['player',['../header_8h.html#ac5a8201c5f6bbce303ec36500d67b6d8',1,'header.h']]],
  ['player_5ft_1',['player_t',['../structplayer__t.html',1,'']]],
  ['prota_5fs_2',['prota_s',['../structprota__s.html',1,'']]]
];
