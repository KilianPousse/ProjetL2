var searchData=
[
  ['player_0',['player',['../header_8h.html#ac5a8201c5f6bbce303ec36500d67b6d8',1,'header.h']]]
];
