var searchData=
[
  ['initgui_0',['initGUI',['../gui_8c.html#a5a1d9af3e77f4b4034abad93f5b610ec',1,'initGUI():&#160;gui.c'],['../header_8h.html#a5a1d9af3e77f4b4034abad93f5b610ec',1,'initGUI():&#160;gui.c']]],
  ['initmap_1',['initMap',['../map_8c.html#a464977f8317c50346420be433fa5320d',1,'initMap(map_t *m):&#160;map.c'],['../header_8h.html#a464977f8317c50346420be433fa5320d',1,'initMap(map_t *m):&#160;map.c']]],
  ['initplayer_2',['InitPlayer',['../header_8h.html#a2a785a496d04917a541a6b22c23c1f6c',1,'player.c']]]
];
