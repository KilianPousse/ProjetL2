#include <stdio.h>
#include <stdlib.h>

#include "hotbar.h"
#include "inventary.h"




int main(  ){


    inventary.hotbar = {
        {1, 1},
        {2 , 3},
        {0, 0},
        {4, 99},
        {1, 95},
        {0, 0}
    };


    inventary.pcpl = {
        {2, 2},
        {1, 1},
        {0, 0},
        {0, 0},
        {2 , 3},
        {1, 67},
        {0, 0},
        {4, 99},
        {1, 11},
        {1, 95},
        {0, 0},
        {0, 0},
        {0, 0},
        {0, 0},
        {0, 0},
        {0, 0},
        {0, 0},
        {0, 0}
    };

    for(int i=0; i<6; i++){
        printf("[id:%02d|nb:%02d] ", inventary.hotbar[i].id, inventary.hotbar[i].nb );
    }
    printf("\n");


    return 0;
}