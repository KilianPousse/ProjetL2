var searchData=
[
  ['x_0',['x',['../structplayer__t.html#ad9a9183e105b3ca0e4ba28cb0137dd24',1,'player_t::x'],['../structmap__t.html#a2475ddf9dc1e5a5a9f545ae2472af70d',1,'map_t::x']]]
];
