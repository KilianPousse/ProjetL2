var searchData=
[
  ['dir_0',['dir',['../structplayer__t.html#a891d4884151019a2190987925120548b',1,'player_t']]]
];
