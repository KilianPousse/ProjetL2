var searchData=
[
  ['vers_5fgame_0',['VERS_GAME',['../header_8h.html#ae1172ce9e6d87d89b0d879854bda7ef3',1,'header.h']]],
  ['vit_1',['vit',['../structplayer__t.html#a14e5a4b4504a4e3326da6ae2940901c2',1,'player_t']]]
];
