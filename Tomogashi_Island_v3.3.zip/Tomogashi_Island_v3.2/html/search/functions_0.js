var searchData=
[
  ['action_0',['action',['../header_8h.html#a7b4cb3f3f41c37d07dbf7c2991efcdc7',1,'player.c']]],
  ['afficher_5fcadre_1',['afficher_cadre',['../display_8c.html#aab92356d555eff37509394d0a6af7666',1,'afficher_cadre(SDL_Window *window, SDL_Renderer *renderer):&#160;display.c'],['../header_8h.html#aab92356d555eff37509394d0a6af7666',1,'afficher_cadre(SDL_Window *window, SDL_Renderer *renderer):&#160;display.c']]],
  ['afficher_5fpose_5fmap_2',['afficher_pose_map',['../display_8c.html#a5f0f9817e9ea63b9fd4e2f593b56a3ab',1,'afficher_pose_map():&#160;display.c'],['../header_8h.html#a5f0f9817e9ea63b9fd4e2f593b56a3ab',1,'afficher_pose_map():&#160;display.c']]]
];
