var searchData=
[
  ['tileaction_0',['tileAction',['../main_8c.html#af32cba74c2d07be494e7183bf3d3ee97',1,'tileAction():&#160;main.c'],['../header_8h.html#af32cba74c2d07be494e7183bf3d3ee97',1,'tileAction():&#160;main.c']]],
  ['tilevalue_1',['tileValue',['../map_8c.html#a3735bd7f3781679e156403436a12712d',1,'tileValue(int i_map, int x, int y):&#160;map.c'],['../header_8h.html#a3735bd7f3781679e156403436a12712d',1,'tileValue(int i_map, int x, int y):&#160;map.c']]]
];
