#define IMG_ICON "bin/assets/icon.png"
/*
#define WHITE_COLOR {0xFF, 0xFF, 0xFF, 0xFF}
#define BLACK_COLOR {0x00, 0x00, 0x00, 0xFF}
*/

#define FULL_WHITE_COLOR {0xFF, 0xFF, 0xFF}
#define FULL_BLACK_COLOR {0x00, 0x00, 0x00}

#define WHITE_COLOR {0xF3, 0xF4, 0xE7}

#define IMG_SPRITE "bin/assets/textures/sprites/haric"




#define IMG_GUI_HOUR "bin/assets/textures/gui/hour.png"