#define TILE_EMPTY 0
#define TILE_WATER -1
