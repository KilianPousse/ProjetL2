#define TILE_EMPTY 0
#define TILE_WATER -1

#define TILE_ENTER_HOUSE -10
#define TILE_EXIT_HOUSE -11

#define TILE_PNJ -20
