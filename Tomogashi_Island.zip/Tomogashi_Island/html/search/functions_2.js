var searchData=
[
  ['outmap_0',['outMap',['../map_8c.html#a1a9266e5ccf5dadd51b799855091a22a',1,'outMap(map_t m):&#160;map.c'],['../header_8h.html#a1a9266e5ccf5dadd51b799855091a22a',1,'outMap(map_t m):&#160;map.c']]],
  ['outwindow_1',['outWindow',['../main_8c.html#adbbaf84635f70af9669df2aaa79de7b3',1,'outWindow(player_t p):&#160;main.c'],['../header_8h.html#adbbaf84635f70af9669df2aaa79de7b3',1,'outWindow(player_t p):&#160;main.c']]]
];
