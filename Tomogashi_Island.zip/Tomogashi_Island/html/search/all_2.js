var searchData=
[
  ['failure_0',['FAILURE',['../header_8h.html#a6d58f9ac447476b4e084d7ca383f5183',1,'header.h']]]
];
