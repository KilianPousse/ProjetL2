var searchData=
[
  ['window_5fname_0',['WINDOW_NAME',['../header_8h.html#a2d6acae8f9b752a5d85795baf1005907',1,'header.h']]]
];
