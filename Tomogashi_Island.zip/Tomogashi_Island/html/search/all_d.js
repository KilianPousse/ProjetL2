var searchData=
[
  ['y_0',['y',['../structplayer__t.html#a23e37c6edab398b7d45261b54decfec8',1,'player_t::y'],['../structmap__t.html#a87af8f6b5b941dae8dbf8172adf8c39b',1,'map_t::y']]]
];
