var searchData=
[
  ['player_5ft_0',['player_t',['../structplayer__t.html',1,'']]]
];
