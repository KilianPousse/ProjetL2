var searchData=
[
  ['x_0',['x',['../structplayer__t.html#ad9a9183e105b3ca0e4ba28cb0137dd24',1,'player_t::x'],['../structmap__t.html#aa652b86191d57a63175e30aafae994e1',1,'map_t::x']]]
];
