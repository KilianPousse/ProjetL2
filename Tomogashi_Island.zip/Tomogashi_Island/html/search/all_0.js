var searchData=
[
  ['dir_0',['dir',['../structplayer__t.html#a891d4884151019a2190987925120548b',1,'player_t']]],
  ['dir_5ft_1',['dir_t',['../header_8h.html#a32db8bfae4e3fc9908e95d227f464ad0',1,'header.h']]]
];
