var searchData=
[
  ['name_5fprog_0',['NAME_PROG',['../header_8h.html#ace02b6fb534354e5ba0b2a78218b4a8e',1,'header.h']]],
  ['nb_5ftile_5fx_1',['NB_TILE_X',['../header_8h.html#a7261b6a70ea8aeccc36578e361f52777',1,'header.h']]],
  ['nb_5ftile_5fy_2',['NB_TILE_Y',['../header_8h.html#a3aad3e50e3f36b38e7cebef206a7b094',1,'header.h']]]
];
