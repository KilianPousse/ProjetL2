/**
 * \file map.c
 * \brief Sripte de la gestion de la map
 * \details Ensemble des fonctions qui utilise la map
 * \author Pousse Kilian - Pierre Elona - Vallee Alban 
 * \version alpha 1.1
 * \date 30/01/2024
**/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

#include "header.h"
#include "style.h"

/**
 * \fn int initMap(map_t * m);
 * \brief Permet d'initialiser la map
 * \param m est la map du jeu à initialiser
**/
int initMap(map_t * m){

    






    return SUCCESS;
}



/**
 * \fn int outMap(map_t m);
 * \brief Permet de savoir si le joueur est hors de la map
 * \param m est la map du jeu
 * \return 0 --> est toujours dans la map
 * \return 1 --> sortie par la gauche
 * \return 2 --> sortie par en haut
 * \return 3 --> sortie par la droite
 * \return 4 --> sortie par en bas
**/
int outMap(map_t m){

    if( m.x < 0 )
        return 1;

    if( m.y < 0 )
        return 2;

    if( m.x >= SIZE_MAP_X )
        return 3;

    if( m.x >= SIZE_MAP_Y )
        return 4;

    return 0;
}