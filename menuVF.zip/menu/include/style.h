/*Fichier qui stock tout les chemin*/

#define IMG_BOUTON_PLAY "play1.png"
#define IMG_BOUTON_PLAY_CLIQUE "play2.png"
#define IMG_BOUTON_NEW "new1.png"
#define IMG_BOUTON_NEW_CLIQUE "new2.png"
#define IMG_BOUTON_SET "set1.png"
#define IMG_BOUTON_SET_CLIQUE "set2.png"
#define IMG_BOUTON_QUIT "quit1.png"
#define IMG_BOUTON_QUIT_CLIQUE "quit2.png"
#define IMG_ICON "icon.jpeg"
#define IMG_FOND "fondtemp.jpeg"
