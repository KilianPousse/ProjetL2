#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

typedef struct item_s{
    /*Image de l'item*/
    char * nom;
    char * type;    /*cosmétique/plantation/poisson/autre*/
    /*intéraction => porter/poser/manger */
}item_t;

typedef struct meuble_s{
    /*image du meuble*/
    char * nom;
    char * type;
    /*intéraction*/
}meuble_t;

typedef struct musique_s{
    /*à définir plus tard*/
    /*change en fonction de la zone*/
}musique_t;

typedef struct argent_s{
    char * nom;
    /*image de l'image*/
    int val;
}argent_t;


typedef struct barre_tache_s{
    item_t tab[10];
    int obj_indice;
    /*Image de la barre de tache*/
}barre_tache_t;
    
typedef struct prota_s{
    /*Sprite*/
    item_t main;
    barre_tache_t inventaire;
}proba_t;

typedef struct skin_s{
    /*Image*/
    char * nom;
}skin_t;

typedef struct bouton_s{
    char * texte; /*Définiton des nom des boutons*/
    SDL_Rect rectangle;  /*Définiton du rectangle pour savoir si le joueur clique dedans ou pas*/
    SDL_Texture * image; /*Image du bouton si pas de clique*/
    SDL_Texture * clique; /*Image du bouton si le joueur clique dessus*/
}bouton_t;