#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "header.h"
#include "style.h"
#include "struct_v2.h"

/*Définiton variable globale*/

#define SCREEN_HEIGHT 480
#define SCREEN_WIDGHT 640
#define TAILLE 4
SDL_Window * window = NULL;
SDL_Renderer * rendu = NULL;
SDL_Event evenement;

void destruction(bouton_t * bouton,SDL_Window * window,SDL_Texture * texture){
        /*Destruction fenetre*/
    for(int j = 0; j < TAILLE ; j++){
        SDL_DestroyTexture(bouton[j].image);
        SDL_DestroyTexture(bouton[j].clique);
    }
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(texture);
    SDL_Quit();
}



/*Gameexit*/
void GameExit( int exit_value ){

    //freeMap(&map);
    //FreePlayer();
    //freeGUI();

    //if(icon != NULL){
      //  SDL_FreeSurface(icon);
        //icon = NULL;
    //}
    
    if(renderer != NULL){
        SDL_DestroyRenderer(renderer);
        renderer = NULL;
    }

    if(window != NULL){
        SDL_DestroyWindow(window);
        window = NULL;
    }
    //if(hour_Font != NULL){
      //  TTF_CloseFont(hour_Font);
        //hour_Font = NULL;
    //}

    //TTF_Quit();
    SDL_Quit();
    

    exit( exit_value );

}


/*Structure stockée dans struct.h*/

/*Permet de cherger une image*/
SDL_Texture * chargerTexture (char * chemin, SDL_Renderer * rendu){
    SDL_Surface * surface = IMG_Load(chemin);
    if(!surface){
        printf("L'image n'as pas pu être chargée");
        return NULL;
    }
    SDL_Texture * texture = SDL_CreateTextureFromSurface(rendu,surface);
    SDL_FreeSurface(surface);
    return texture;
}



/*En SDL obligé de mettre une fonction à argument variable*/
int main(int argc, char * argv[]){
    /*Initialisation fenêtre*/


    /* Initialisation de la SDL */
    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != FAILURE){
        ErrorLog("Échec de l'initialisation de la SDL");
    }


    window = SDL_CreateWindow(WINDOW_NAME,
                            SDL_WINDOWPOS_CENTERED,
                            SDL_WINDOWPOS_CENTERED,
                            WINDOW_WIDTH,
                            WINDOW_HEIGHT,
                            0
                            );

    

    /*Test si fenêtre existe*/
    if(window == NULL){
        ErrorLog("Erreur init fenêtre");
    }
    rendu = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	if(rendu == NULL){
        SDL_Delay(2000);
        ErrorLog("Erreur à la création du renderer");
    }
    /*Chargement de l'icone du jeu*/
    icon = IMG_Load(IMG_ICON);
    if (icon == NULL) {
        WarningLog("Impossible à charger l'icon de la fenêtre");
    }
    SDL_SetWindowIcon(window, icon);

    SDL_Surface * fond = IMG_Load(IMG_FOND);
    if(fond == NULL){
        printf("PAS FOND\n");
    }
    SDL_Rect rectangle= {0,0,100,100};

    /*Définition des boutons*/

    bouton_t menu[TAILLE];
    menu[0].texte = "jouer";
    menu[1].texte = "nouvelle partie";
    menu[2].texte = "parametre";
    menu[3].texte = "quitter";

    /*Chargement des images*/
    menu[0].image = chargerTexture(IMG_BOUTON_PLAY,rendu);
    menu[0].clique = chargerTexture(IMG_BOUTON_PLAY_CLIQUE,rendu);
    menu[1].image = chargerTexture(IMG_BOUTON_NEW,rendu);
    menu[1].clique = chargerTexture(IMG_BOUTON_NEW_CLIQUE,rendu);
    menu[2].image = chargerTexture(IMG_BOUTON_SET,rendu);
    menu[2].clique = chargerTexture(IMG_BOUTON_SET_CLIQUE,rendu);
    menu[3].image = chargerTexture(IMG_BOUTON_QUIT,rendu);
    menu[3].clique = chargerTexture(IMG_BOUTON_QUIT_CLIQUE,rendu);

    SDL_Texture * texture;
    /*Calcul des postitions et des rectangles => pour savoir ou l'utilisateur clique*/
    int mrec = 100;
    int espace = 10;
    int totalheight = (mrec + espace)*TAILLE; 
    int y = (SCREEN_HEIGHT - totalheight) / 2 + 300; /*On ajouter pour centrer sur l'ecran*/
    int i;
    for(i = 0; i < TAILLE; i++){
        menu[i].rectangle.x = (SCREEN_WIDGHT + espace);
        menu[i].rectangle.y = y + (mrec + espace) * i; 
        menu[i].rectangle.w = 200;
        menu[i].rectangle.h = mrec;
    }
    int quitter = 0;
    int mousex,mousey;

    while(!quitter){
        
        while(SDL_PollEvent(&evenement) != 0){
            if(evenement.type == SDL_QUIT){
                quitter = 1;
            }
            else if(evenement.type == SDL_MOUSEBUTTONDOWN){
                
                SDL_GetMouseState(&mousex,&mousey);
            }
            
             /*On récupère les coordonnées de la souris*/
            int i;
            for(i = 0; i < 4; i++){
                if(SDL_PointInRect(&(SDL_Point){mousex,mousey},&menu[i].rectangle)){
                    printf("Cliquer sur %s\n",menu[i].texte);
                    if(menu[i].texte == "jouer"){
                        destruction(menu,window,texture);
                        return 1;
                    }
                    if(menu[i].texte == "nouvelle partie"){
                        return 2;
                    }
                    if(menu[i].texte == "parametre"){
                        destruction(menu,window,texture);
                        return 3;
                    }
                    if(menu[i].texte == "quitter"){
                        destruction(menu,window,texture);
                        return 4;
                    }
                    break;
                }
            }
        
        }
    
        //SDL_RenderClear(rendu);

        texture = SDL_CreateTextureFromSurface(rendu,fond); /*utiliser ce bloc a chaque bouton*/
        if (texture == NULL) {
            WarningLog("Impossible de charger la texture du background");
        }
        SDL_RenderCopy(rendu, texture, NULL, NULL); /*Rectangle*/
        SDL_DestroyTexture(texture);

        /*Rendu des items*/
        for(i = 0;i<4;i++){
            SDL_RenderCopy(rendu, menu[i].image, NULL, &(menu[i].rectangle)); /*Rectangle*/
                /*Si on clique alors*/
                if(SDL_PointInRect(&(SDL_Point){mousex,mousey},&menu[i].rectangle)){

                    SDL_RenderCopy(rendu, menu[i].clique, NULL, &(menu[i].rectangle)); /*Rectangle*/
                    
                    
                }

        
        }
        SDL_RenderPresent(rendu);
    }

    /*musique*/
    /*Gestion musique SDL MIXER*/

    return 0;
}