#!/bin/bash
./bin/Tomogashi_Island
