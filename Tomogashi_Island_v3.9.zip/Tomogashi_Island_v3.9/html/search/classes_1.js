var searchData=
[
  ['barre_5ftache_5fs_0',['barre_tache_s',['../structbarre__tache__s.html',1,'']]]
];
