var searchData=
[
  ['limit_5fper_5fline_0',['LIMIT_PER_LINE',['../header_8h.html#a210524a73e29beec0bbfb0ce037f2e34',1,'header.h']]]
];
