#include <stdio.h>
#include <stdlib.h>

#include "header.h"
#include "inventary.h"


int inventary_clear(){

    for(int i=0; i<NB_HOTBAR_ITEM; i++){
        inventary.hotbar[i].nb = 0;
        inventary.hotbar[i].id = 0;
    }

    for(int i=0; i<NB_INVENTARY_ITEM; i++){
        inventary.pcpl[i].nb = 0;
        inventary.pcpl[i].id = 0;
    }

    return 0;
}


void inventary_affiche(  ){


    for(int i=0; i<NB_INVENTARY_ITEM; i++){
        if(i%NB_HOTBAR_ITEM == 0)
            printf("\n");
        printf(" [id:%02d|nb:%02d]", inventary.pcpl[i].id, inventary.pcpl[i].nb );
    }
    printf("\n");


    printf("-------------------------------------------------------------------------------------\n");

    for(int i=0; i<NB_HOTBAR_ITEM; i++){
        printf(" [id:%02d|nb:%02d]", inventary.hotbar[i].id, inventary.hotbar[i].nb );
    }
    printf("\n");


}

int inventary_give( item_t * item ){

    if( item->nb > MAX_ITEM_STACK )
        item->nb = MAX_ITEM_STACK;

    int i_hotbar = -1;
    int i_pcpl = -1;

    for(int i=0; i<NB_HOTBAR_ITEM; i++){

        if( i_hotbar < 0 && inventary.hotbar[i].nb <= 0 && inventary.hotbar[i].id == 0 )
            i_hotbar = i;

        if( inventary.hotbar[i].id == item->id  ){
            inventary.hotbar[i].nb += item->nb;
            item->nb = inventary.hotbar[i].nb - MAX_ITEM_STACK;
            if( inventary.hotbar[i].nb > MAX_ITEM_STACK )
                inventary.hotbar[i].nb = MAX_ITEM_STACK;

            if( item->nb <= 0 )
                return 0;
        }

    }

    for(int i=0; i<NB_INVENTARY_ITEM; i++){

        if( i_hotbar < 0 && i_pcpl < 0 && inventary.pcpl[i].nb <= 0 && inventary.pcpl[i].id == 0 )
            i_pcpl = i;

        if( inventary.pcpl[i].id == item->id  ){
            inventary.pcpl[i].nb += item->nb;
            item->nb = inventary.pcpl[i].nb - MAX_ITEM_STACK;
            if( inventary.pcpl[i].nb > MAX_ITEM_STACK )
                inventary.pcpl[i].nb = MAX_ITEM_STACK;

            if( item->nb <= 0 )
                return 0;
        }

    }

    if( item->nb > 0 ){

        if( i_hotbar >= 0 ){
            inventary.hotbar[i_hotbar] = *item;
            return 0;
        }

        if( i_pcpl >= 0 ){
            inventary.pcpl[i_pcpl] = *item;
            return 0;
        }

    }

    return 1;
}

int main(int argc, char * argv[]){

    printf("TEST FONCTION: 'invetary_give()' si l'inventaire est vide\n");

    inventary_affiche();

    item_t item = {1, 20}; // Item a rajouter
    printf("\nAjout de [id:%d|nb:%d]\n", item.id, item.nb);
    inventary_give(&item);


    inventary_affiche();


    printf("\n\nTEST FONCTION: 'invetary_give()' si l'inventaire est plein\n");
    for(int i=0; i<NB_INVENTARY_ITEM; i++){
        inventary.pcpl[i].id = ID_ITEM_BLE;
        inventary.pcpl[i].nb = MAX_ITEM_STACK;
    }
    for(int i=0; i<NB_HOTBAR_ITEM; i++){
        inventary.hotbar[i].id = ID_ITEM_BLE;
        inventary.hotbar[i].nb = MAX_ITEM_STACK;
    }

    inventary_affiche();

    item.id = 1;
    item.nb = 20; // Item a rajouter
    printf("\nAjout de [id:%d|nb:%d]\n", item.id, item.nb);
    inventary_give(&item);


    inventary_affiche();




    printf("\n\nTEST FONCTION: 'invetary_give()' si la hotbar est vide un peu rempli\n");
    inventary_clear();
    for(int i=0; i<NB_INVENTARY_ITEM; i++){
        inventary.pcpl[i].id = ID_ITEM_BLE;
        inventary.pcpl[i].nb = MAX_ITEM_STACK;
    }
    inventary.hotbar[0].id = 2; inventary.hotbar[0].nb = 4;
    inventary.hotbar[1].id = 1; inventary.hotbar[1].nb = 96;
    inventary.hotbar[2].id = 3; inventary.hotbar[2].nb = 47;
    inventary.hotbar[3].id = 1; inventary.hotbar[3].nb = 14;

    inventary_affiche();

    
    item.id = 1;
    item.nb = 20; // Item a rajouter
    printf("\nAjout de [id:%d|nb:%d]\n", item.id, item.nb);
    inventary_give(&item);


    inventary_affiche();


    




    return 0;
}