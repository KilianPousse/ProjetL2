var searchData=
[
  ['tile_5faction_0',['tile_action',['../header_8h.html#a9c82afb7a8f8310900500133010edb37',1,'header.h']]],
  ['tps_5fgame_1',['tps_game',['../header_8h.html#acddea2e6e4a413a85c9d546d69132dd1',1,'header.h']]]
];
