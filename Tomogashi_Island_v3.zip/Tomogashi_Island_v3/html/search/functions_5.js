var searchData=
[
  ['gui_5fprint_5fhour_0',['GUI_print_hour',['../gui_8c.html#a1b0bdc2c7f72e1a58b6a6ae93a8863c0',1,'GUI_print_hour():&#160;gui.c'],['../header_8h.html#a1b0bdc2c7f72e1a58b6a6ae93a8863c0',1,'GUI_print_hour():&#160;gui.c']]]
];
