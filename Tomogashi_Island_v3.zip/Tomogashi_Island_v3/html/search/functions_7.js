var searchData=
[
  ['limit_5ffps_0',['limit_fps',['../main_8c.html#ac2f8a53b6509da854f35d8cdaa18d3a6',1,'limit_fps(unsigned int limit):&#160;main.c'],['../header_8h.html#ac2f8a53b6509da854f35d8cdaa18d3a6',1,'limit_fps(unsigned int limit):&#160;main.c']]]
];
