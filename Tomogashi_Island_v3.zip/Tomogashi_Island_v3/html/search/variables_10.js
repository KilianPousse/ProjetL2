var searchData=
[
  ['y_0',['y',['../structplayer__t.html#a23e37c6edab398b7d45261b54decfec8',1,'player_t::y'],['../structmap__t.html#a92f18a1b3cdff5257ee6196dae7cc8f0',1,'map_t::y']]]
];
